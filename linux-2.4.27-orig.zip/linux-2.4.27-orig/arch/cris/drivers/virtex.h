int virtex_writereg(unsigned short theReg, unsigned short theValue);
unsigned short virtex_readreg(unsigned short theReg);
